You can download the x64 version of the FFmpeg libraries from:
https://www.microncode.com/downloads/ffmpeg58x64.7z

The ffmpeg libraries licensed under
LGPL.

You can add those libraries to your commercial projects by
giving relevant credits.
